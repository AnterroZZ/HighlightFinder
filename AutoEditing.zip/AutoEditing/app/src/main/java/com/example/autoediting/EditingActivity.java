package com.example.autoediting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.transition.ChangeBounds;
import android.transition.Scene;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class EditingActivity extends AppCompatActivity {

    private ImageView imageView;
    private TextView valueOfImage;
    private ProgressBar progressBar;
    private float calculatedValue;

    private Transition transition;
    private Scene normalScene;
    private Scene infoScene;

    private TextView mImageSizeTextView;
    private TextView mTimeToCalculateOneTextView;
    private TextView mTimeToCalculateTotalTextView;

    private long startTime;
    private long endTime;
    private long longCalculationTime;
    private float floatCalculationTime;
    private int imageHeight;
    private int imageWidth;


    private ViewGroup sceneRoot;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editing);

        imageView = findViewById(R.id.imageView);
        valueOfImage = findViewById(R.id.imageValue);
        progressBar = findViewById(R.id.progressBar);
        sceneRoot = findViewById(R.id.scene_root);

        normalScene = Scene.getSceneForLayout(sceneRoot, R.layout.activity_editing_normal, this);
        infoScene = Scene.getSceneForLayout(sceneRoot, R.layout.activity_editing_more_info, this);


        Intent intent = getIntent();
        Uri image = (Uri) intent.getExtras().get(StartingActivity.UPLOADED_IMAGE);
        transition = new ChangeBounds();




        Bitmap imageBitmap = null;
        try {
            imageBitmap = getThumbnail(image);
        } catch (IOException e) {
            e.printStackTrace();
        }
        imageView.setImageBitmap(imageBitmap);
        new BitmapToSingleValue().execute(imageBitmap);

    }

    public void showInfo(View view) {
        switch (view.getId())
        {
            case R.id.bigInfo:
                TransitionManager.go(normalScene, transition);
                valueOfImage = findViewById(R.id.imageValue);
                valueOfImage.setText(String.valueOf(calculatedValue));
                break;
            case R.id.smallInfo:
                TransitionManager.go(infoScene, transition);

                valueOfImage = findViewById(R.id.imageValue);
                mImageSizeTextView = findViewById(R.id.imageSize);
                mTimeToCalculateOneTextView = findViewById(R.id.oneTimeValue);
                mTimeToCalculateTotalTextView = findViewById(R.id.totalTimeValue);

                valueOfImage.setText(String.valueOf(calculatedValue));
                mTimeToCalculateOneTextView.setText(String.valueOf(milisToSec(floatCalculationTime)));
                mTimeToCalculateTotalTextView.setText(String.valueOf(milisToSec(floatCalculationTime*30)));
                String mImageSize = imageWidth + "x" + imageHeight;
                mImageSizeTextView.setText(mImageSize);
                break;
        }
    }

    private float milisToSec(float floatCalculationTime) {
        float modulo = floatCalculationTime % 10;
        return (floatCalculationTime - modulo) / 1000;
    }

    private class BitmapToSingleValue extends AsyncTask <Bitmap, Integer, Float>
    {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            startTime = System.currentTimeMillis();
            valueOfImage.setVisibility(View.INVISIBLE);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setMax(100);
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);

            progressBar.setProgress(values[0]);
        }

        @Override
        protected Float doInBackground(Bitmap... bitmaps) {
            ArrayList<Float> values = new ArrayList<>();
            imageWidth = bitmaps[0].getWidth();
            imageHeight = bitmaps[0].getHeight();
            for(int x=0; x<imageWidth; x++)
            {
                for(int y=0; y<imageHeight; y++)
                {
                    int pixel = bitmaps[0].getPixel(x,y);
                    float redValue = Color.red(pixel) / 255;
                    float blueValue = Color.blue(pixel) / 255;
                    float greenValue = Color.green(pixel) / 255;
                    float pixelValue = (redValue + blueValue + greenValue) / 3;
                    values.add(pixelValue);
                }
                publishProgress(x * 100 / imageWidth);
            }
            float sum = 0;
            if(!values.isEmpty())
            {
                for(Float value: values)
                {
                    sum += value;
                }
                return sum / values.size();
            }
            return Float.valueOf(3);
        }



        @Override
        protected void onPostExecute(Float aFloat) {
            endTime = System.currentTimeMillis();
            longCalculationTime = endTime-startTime;
            floatCalculationTime = longCalculationTime;
            calculatedValue = Float.valueOf(aFloat);
            valueOfImage.setText(String.valueOf(calculatedValue));
            valueOfImage.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.INVISIBLE);

        }
    }

    private Bitmap getThumbnail(Uri image) throws FileNotFoundException, IOException{
        InputStream inputStream = getContentResolver().openInputStream(image);

        BitmapFactory.Options onlyBoundsOptions = new BitmapFactory.Options();
        onlyBoundsOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeStream(inputStream, null, onlyBoundsOptions);
        inputStream.close();

        int originalSize = (onlyBoundsOptions.outHeight > onlyBoundsOptions.outWidth) ? onlyBoundsOptions.outHeight : onlyBoundsOptions.outWidth;

        BitmapFactory.Options bitmapOptions = new BitmapFactory.Options();
        bitmapOptions.inPreferredConfig=Bitmap.Config.ARGB_8888;
        inputStream = this.getContentResolver().openInputStream(image);
        Bitmap bitmap = BitmapFactory.decodeStream(inputStream, null, bitmapOptions);
        inputStream.close();

        return bitmap;
    }
}

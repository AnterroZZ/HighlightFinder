package com.example.autoediting;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.animation.ValueAnimator;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;

public class StartingActivity extends AppCompatActivity {

    private String takePhoto;
    private String chooseGallery;
    private String cancelDialog;
    private ImageView backgroundOne;
    private ImageView backgroundTwo;
    private Toolbar mToolbar;
    private static final int RESULT_GALLERY = 2;
    private static final int RESULT_CAMERA = 1;
    public static final String UPLOADED_IMAGE = "uploaded";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_starting);

        takePhoto = getResources().getString(R.string.take_photo);
        chooseGallery = getResources().getString(R.string.choose_gallery);
        cancelDialog = getResources().getString(R.string.cancel);

        backgroundOne = findViewById(R.id.background_one);
        backgroundTwo = findViewById(R.id.background_two);

        setUpToolBar();
        ValueAnimator animator = ValueAnimator.ofFloat(0.0f, 1.0f);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.setInterpolator(new LinearInterpolator());
        animator.setDuration(10000L);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float progress = (float) animation.getAnimatedValue();
                float width = backgroundOne.getWidth();
                float translationX = width * progress;
                backgroundOne.setTranslationX(translationX);
                backgroundTwo.setTranslationX(translationX-width);
            }
        });
        animator.start();
    }

    private void setUpToolBar() {
    }

    public void uploadMovie(View view) {
        Toast.makeText(this, "Here you will upload movies for auto editing", Toast.LENGTH_SHORT).show();
    }

    public void uploadImage(View view) {
        final String[] uploadOptions = {takePhoto, chooseGallery, cancelDialog};
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Photo!");
        builder.setItems(uploadOptions, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(uploadOptions[which].equals(takePhoto))
                {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    File f = new File(android.os.Environment.getExternalStorageDirectory(),"temp.jpg");
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(f));
                    startActivityForResult(intent, RESULT_CAMERA);
                }else if(uploadOptions[which].equals(chooseGallery))
                {
                    Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(galleryIntent, RESULT_GALLERY);
                }else if(uploadOptions[which].equals(cancelDialog))
                {
                    dialog.dismiss();
                }
            }
        });
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK)
        {
            if(requestCode== RESULT_GALLERY && data!=null)
            {
                Intent editActivity = new Intent(this, EditingActivity.class);
                Uri selectedImage = data.getData();

                editActivity.putExtra(UPLOADED_IMAGE, selectedImage);
                startActivity(editActivity);

            }
        }
    }
}
